
#include <windows.h>
#include <commctrl.h>
#include "wincontrols.h"

typedef struct control_s
{
	HWND hWnd;
	int ResourceID;
} control_t;

typedef struct progressbar_s
{
	control_t control;

	int Minimum;
	int Maximum;
	int Step;
} progressbar_t;


int CreateProgressBar (HWND ParentWindow, int ResourceID)
{
	return 0;
}

