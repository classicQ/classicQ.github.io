
// windows UI interaction functions
void DoEvents (void);
void StepProgressBar (void);
void SetupProgressBar (int nMinRange, int nMaxRange);
void UpdateProgressNotify (char *format, ...);
