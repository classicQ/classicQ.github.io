//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by WinMHColour.rc
//
#define IDD_DIALOG_MAIN                 101
#define IDI_ICON_APPICON                104
#define IDI_ICON_CDDRIVE                105
#define IDI_ICON_FOLDERCLOSED           106
#define IDI_ICON_FIXEDDRIVE             107
#define IDI_ICON_MYCOMPUTER             108
#define IDI_ICON_NETWORKDRIVE           109
#define IDI_ICON_OPENFOLDER             110
#define IDI_ICON_REMOVABLE              111
#define IDI_ICON_QUAKEPAK               112
#define IDD_DIALOG_PROCESS              114
#define IDC_BUTTON_LOADFILE             1001
#define IDC_EDIT_BSPFILE                1002
#define IDC_GB_OPTIONS                  1003
#define IDC_GB_EXTRASAMPLING            1004
#define IDC_RB_NOEXTRASAMPLING          1005
#define IDC_RB_2XEXTRASAMPLING          1006
#define IDC_RB_4XEXTRASAMPLING          1007
#define IDC_GB_LITBEHAVIOUR             1008
#define IDC_CB_GENERATELIT              1009
#define IDC_CB_OVERWRITEBSP             1010
#define IDC_CB_DISTSCALE                1011
#define IDC_CB_RANGESCALE               1012
#define IDC_EDIT_DISTSCALE              1013
#define IDC_EDIT_RANGESCALE             1014
#define IDC_BUTTON_PROCESSFILE          1015
#define IDC_GB_LITBEHAVIOUR2            1016
#define IDC_LBL_MESSAGE                 1017
#define IDC_BUTTON_NEXT                 1017
#define IDC_PB_PROGRESS                 1018
#define IDC_PB_PROGRESSALL              1019
#define IDC_EDIT_PROGRESSNOTIFY         1020
#define IDC_LIST_BSPFILES               1021
#define IDC_BUTTON_ADDFILES             1022
#define IDC_LBL_ALLBSPS                 1023
#define IDC_BUTTON_REMOVE_FILE          1024
#define IDC_BUTTON_REMOVEFILE           1024
#define IDC_BUTTON_REMOVEALL            1025
#define IDC_LBL_CURRENTBSP              1026
#define IDC_SPIN1                       1027
#define IDC_SPIN_DISTSCALE              1027
#define IDC_SPIN_RANGESCALE             1028
#define IDC_CB_OVERWRITEBSP2            1029
#define IDC_CB_DRYRUN                   1029
#define ID_BUTTON_OPEN                  1030
#define ID_BUTTON_CANCEL                1031
#define IDC_LBL_PAKNAME                 1033
#define IDC_LB_BSPSINPAK                1037
#define IDC_LBL_BSPCOUNT                1038
#define IDC_TREE1                       1039
#define IDC_TREE_FILES                  1039
#define IDC_BTN_ADDFROMTREE             1041
#define IDC_EDIT_PATH                   1042
#define IDC_BUTTON1                     1044
#define IDC_BTN_ADDFOLDER               1044
#define IDC_SLIDER_OVERSAMPLING         1045
#define IDC_LBL_OVERSAMPLING            1046
#define IDC_SLIDERDISTSCALE             1047
#define IDC_SLIDER_DISTSCALE            1047
#define IDC_LBL_DISTSCALE               1048
#define IDC_LBL_COLOURRANGE             1048
#define IDC_SLIDER_DISTSCALE2           1049
#define IDC_SLIDER_RANGESCALE           1049
#define IDC_LBL_RANGESCALE              1050
#define IDC_LV_BSPFILES                 1052
#define IDC_LBL_CURRENT                 1054
#define IDC_COMBO_CURRENTPATH           1055
#define IDC_PB_PROGRESSBSP              1056
#define IDC_LBL_ALL                     1057
#define ID_BUTTON_OK                    1058

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        115
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1060
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
