
void *QHeap_Alloc (int size);
void Heap_Free (void);
