WinMHColour2010
---------------

This release fixes a bug in the original WinMHColour from 2009 that prevented some people from being able to add
BSPs or PAKs for processing.  I've also updated the project files to VCPP 2008 level.

No other changes have been made.